public enum DataType {
    DATA_ENCRYPTED,
    DATA_DECRYPTED;
}

